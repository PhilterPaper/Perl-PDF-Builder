package PDF::Builder::Basic::PDF;

use strict;
use warnings;

our $VERSION = '3.023'; # VERSION
our $LAST_UPDATE = '3.020'; # manually update whenever code is changed

=head1 NAME

PDF::Builder::Basic::PDF - Various utilities and support routines

=cut

1;
